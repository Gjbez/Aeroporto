Start-Service RabbitMQ
Get-Service RabbitMQ
