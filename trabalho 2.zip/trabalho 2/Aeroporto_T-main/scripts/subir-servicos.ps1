# Compila a solução e abre cada serviço em uma janela do PowerShell.
# Uso: .\scripts\subir-servicos.ps1            (uma instância de Bagagens)
#      .\scripts\subir-servicos.ps1 -Bagagens 2 (demonstração de escalabilidade)
param([int]$Bagagens = 1)

$ErrorActionPreference = "Stop"
$raiz = Split-Path -Parent $PSScriptRoot

dotnet build (Join-Path $raiz "AeroportoRabbitMQ.sln") -nologo -v q
if ($LASTEXITCODE -ne 0) { throw "Falha na compilação." }

function Subir($projeto) {
    $dir = Join-Path $raiz "src\$projeto"
    Start-Process powershell -WorkingDirectory $dir -ArgumentList "-NoExit", "-Command", "`$Host.UI.RawUI.WindowTitle='$projeto'; dotnet run --no-build"
}

Subir "ServicoPassageiros"
Subir "ServicoVoos"
Subir "ServicoCheckIn"
Subir "ServicoEmbarque"
Subir "ServicoNotificacoes"
1..$Bagagens | ForEach-Object { Subir "ServicoBagagens" }

Write-Host "Serviços iniciados. Painel do RabbitMQ: http://localhost:15672" -ForegroundColor Green
