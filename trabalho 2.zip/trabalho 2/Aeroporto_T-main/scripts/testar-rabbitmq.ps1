Write-Host "Servico:"
Get-Service RabbitMQ
Write-Host "`nPorta 5672:"
Test-NetConnection localhost -Port 5672
Write-Host "`nStatus RabbitMQ:"
rabbitmq-diagnostics.bat status
