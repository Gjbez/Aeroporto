# Execute este script em PowerShell COMO ADMINISTRADOR.
# Requer RabbitMQ Server instalado e o comando rabbitmqctl disponível no PATH.

$ErrorActionPreference = "Stop"

Write-Host "Verificando RabbitMQ..." -ForegroundColor Cyan
rabbitmq-diagnostics.bat status

Write-Host "Criando/ajustando usuario aeroporto..." -ForegroundColor Cyan
rabbitmqctl.bat add_user aeroporto aeroporto123 2>$null
rabbitmqctl.bat change_password aeroporto aeroporto123
rabbitmqctl.bat set_user_tags aeroporto administrator
rabbitmqctl.bat add_vhost /
rabbitmqctl.bat set_permissions -p / aeroporto ".*" ".*" ".*"

Write-Host "Habilitando painel de gerenciamento..." -ForegroundColor Cyan
rabbitmq-plugins.bat enable rabbitmq_management

Write-Host "Configuracao concluida." -ForegroundColor Green
Write-Host "AMQP: localhost:5672"
Write-Host "Painel: http://localhost:15672"
Write-Host "Usuario: aeroporto"
Write-Host "Senha: aeroporto123"
