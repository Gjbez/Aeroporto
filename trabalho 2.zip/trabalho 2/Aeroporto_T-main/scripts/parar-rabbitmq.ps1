Stop-Service RabbitMQ
Get-Service RabbitMQ
