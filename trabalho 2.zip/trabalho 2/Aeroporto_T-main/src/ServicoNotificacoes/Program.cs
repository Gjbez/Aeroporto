using Compartilhado;
using ServicoNotificacoes;

await Host.CreateDefaultBuilder(args)
    .ConfigureServices((context, services) =>
    {
        services.AddRabbitMq(context.Configuration, "ServicoNotificacoes");
        services.AddHostedService<ConsumidorNotificacoes>();
    })
    .Build()
    .RunAsync();
