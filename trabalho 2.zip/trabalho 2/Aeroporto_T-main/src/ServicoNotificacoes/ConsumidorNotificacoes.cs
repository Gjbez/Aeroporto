using System.Collections.Concurrent;
using Compartilhado;
using RabbitMQ.Client.Events;

namespace ServicoNotificacoes;

/// <summary>
/// Consome a fila.notificacoes e "envia" (escreve no console) a mensagem para cada passageiro.
/// Guarda quem fez check-in em cada voo para saber a quem avisar sobre atraso, portão e embarque.
/// </summary>
public sealed class ConsumidorNotificacoes : ConsumidorRabbitMq
{
    private readonly ConcurrentDictionary<string, ConcurrentDictionary<string, string>> _passageirosPorVoo =
        new(StringComparer.OrdinalIgnoreCase);

    public ConsumidorNotificacoes(RabbitMqConnection conexao, ILogger<ConsumidorNotificacoes> logger)
        : base(conexao, logger)
    {
    }

    protected override string Fila => RabbitMqNomes.FilaNotificacoes;

    protected override Task ProcessarAsync(BasicDeliverEventArgs ea, CancellationToken ct)
    {
        switch (ea.RoutingKey)
        {
            case RabbitMqNomes.CheckInRealizado:
                var checkIn = Ler<CheckInRealizado>(ea);
                _passageirosPorVoo.GetOrAdd(checkIn.Voo, _ => new())[checkIn.PassageiroId] = checkIn.NomePassageiro;
                Enviar(checkIn.PassageiroId, checkIn.NomePassageiro,
                    $"Check-in confirmado no voo {checkIn.Voo} às {checkIn.DataHora:HH:mm}.");
                break;

            case RabbitMqNomes.BagagemRegistrada:
                var bagagem = Ler<BagagemRegistrada>(ea);
                Enviar(bagagem.PassageiroId, bagagem.NomePassageiro,
                    $"Bagagem {bagagem.CodigoBagagem} registrada para o voo {bagagem.Voo}.");
                break;

            case RabbitMqNomes.VooAtrasado:
                var atraso = Ler<VooAtrasado>(ea);
                EnviarParaVoo(atraso.Voo,
                    $"O voo {atraso.Voo} está atrasado {atraso.AtrasoMinutos} min ({atraso.Motivo}). Novo horário: {atraso.NovoHorario:HH:mm}.");
                break;

            case RabbitMqNomes.PortaoAlterado:
                var portao = Ler<PortaoAlterado>(ea);
                EnviarParaVoo(portao.Voo,
                    $"O portão do voo {portao.Voo} mudou de {portao.PortaoAnterior} para {portao.NovoPortao}.");
                break;

            case RabbitMqNomes.EmbarqueIniciado:
                var embarque = Ler<EmbarqueIniciado>(ea);
                var local = string.IsNullOrWhiteSpace(embarque.Portao) ? "" : $" no portão {embarque.Portao}";
                EnviarParaVoo(embarque.Voo, $"Embarque do voo {embarque.Voo} iniciado{local}. Dirija-se ao portão.");
                break;

            default:
                Logger.LogWarning("Evento inesperado na {Fila}: {Evento}.", Fila, ea.RoutingKey);
                break;
        }

        return Task.CompletedTask;
    }

    private void EnviarParaVoo(string voo, string texto)
    {
        if (!_passageirosPorVoo.TryGetValue(voo, out var passageiros) || passageiros.IsEmpty)
        {
            Logger.LogInformation("[NOTIFICAÇÃO] Painel do aeroporto: {Texto}", texto);
            return;
        }

        foreach (var (id, nome) in passageiros)
            Enviar(id, nome, texto);
    }

    private void Enviar(string passageiroId, string nome, string texto) =>
        Logger.LogInformation("[NOTIFICAÇÃO] Para {Nome} ({PassageiroId}): {Texto}", nome, passageiroId, texto);
}
