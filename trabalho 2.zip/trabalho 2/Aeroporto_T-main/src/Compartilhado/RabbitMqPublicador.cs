using RabbitMQ.Client;

namespace Compartilhado;

/// <summary>
/// Publica mensagens persistentes com publisher confirms: o await só termina depois
/// que o broker confirma o recebimento (lança PublishException se o broker recusar).
/// </summary>
public sealed class RabbitMqPublicador : IAsyncDisposable
{
    private readonly RabbitMqConnection _connection;
    private readonly SemaphoreSlim _lock = new(1, 1);
    private IChannel? _channel;

    public RabbitMqPublicador(RabbitMqConnection connection) => _connection = connection;

    private async Task<IChannel> GetChannelAsync(CancellationToken ct)
    {
        if (_channel is { IsOpen: true })
            return _channel;

        var conn = await _connection.GetConnectionAsync(ct);
        _channel = await conn.CreateChannelAsync(
            new CreateChannelOptions(
                publisherConfirmationsEnabled: true,
                publisherConfirmationTrackingEnabled: true),
            ct);

        // Garante que exchanges e filas existem mesmo que nenhum consumidor tenha subido ainda.
        await RabbitMqTopologia.ConfigurarAsync(_channel, ct);
        return _channel;
    }

    public async Task PublicarAsync<T>(
        string routingKey,
        T mensagem,
        IDictionary<string, object?>? headers = null,
        string exchange = RabbitMqNomes.ExchangeEventos,
        CancellationToken ct = default)
    {
        var body = JsonMessageSerializer.Serialize(mensagem);
        var properties = new BasicProperties
        {
            ContentType = "application/json",
            Persistent = true,
            MessageId = Guid.NewGuid().ToString(),
            Type = routingKey,
            Timestamp = new AmqpTimestamp(DateTimeOffset.UtcNow.ToUnixTimeSeconds()),
            Headers = headers
        };

        await _lock.WaitAsync(ct);
        try
        {
            var channel = await GetChannelAsync(ct);
            await channel.BasicPublishAsync(exchange, routingKey, false, properties, body, ct);
        }
        finally
        {
            _lock.Release();
        }
    }

    public async ValueTask DisposeAsync()
    {
        if (_channel is not null)
            await _channel.DisposeAsync();
        _lock.Dispose();
    }
}
