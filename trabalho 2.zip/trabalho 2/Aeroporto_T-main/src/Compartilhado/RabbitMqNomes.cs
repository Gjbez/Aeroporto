namespace Compartilhado;

public static class RabbitMqNomes
{
    // Exchanges
    public const string ExchangeEventos = "aeroporto.events";
    public const string ExchangeRetry = "aeroporto.retry";
    public const string ExchangeDlx = "aeroporto.dlx";

    // Filas
    public const string FilaCheckIn = "fila.checkin";
    public const string FilaRetryCheckIn = "fila.retry.checkin";
    public const string DlqCheckIn = "dlq.checkin";
    public const string FilaBagagens = "fila.bagagens";
    public const string FilaEmbarque = "fila.embarque";
    public const string FilaNotificacoes = "fila.notificacoes";

    // Eventos (routing keys)
    public const string SolicitarCheckIn = "SOLICITAR_CHECKIN";
    public const string CheckInRealizado = "CHECKIN_REALIZADO";
    public const string VooAtrasado = "VOO_ATRASADO";
    public const string PortaoAlterado = "PORTAO_ALTERADO";
    public const string EmbarqueIniciado = "EMBARQUE_INICIADO";
    public const string BagagemRegistrada = "BAGAGEM_REGISTRADA";

    // Header com o número da tentativa do Check-in
    public const string HeaderTentativa = "x-tentativa";

    // Retry do Check-in
    public const int RetryTtlMs = 5000;
    public const int MaxTentativasCheckIn = 3;
}
