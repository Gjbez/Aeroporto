using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Compartilhado;

public static class RabbitMqServiceCollectionExtensions
{
    /// <summary>Registra configurações (seção "RabbitMQ"), conexão e publicador.</summary>
    public static IServiceCollection AddRabbitMq(this IServiceCollection services, IConfiguration configuration, string nomeCliente)
    {
        var settings = new RabbitMqSettings();
        configuration.GetSection("RabbitMQ").Bind(settings);

        services.AddSingleton(settings);
        services.AddSingleton(_ => new RabbitMqConnection(settings, nomeCliente));
        services.AddSingleton<RabbitMqPublicador>();
        return services;
    }
}
