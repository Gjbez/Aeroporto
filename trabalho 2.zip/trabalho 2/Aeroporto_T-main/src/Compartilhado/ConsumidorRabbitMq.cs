using System.Text.Json;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using RabbitMQ.Client.Exceptions;

namespace Compartilhado;

/// <summary>
/// Base dos consumidores: conecta (tentando de novo enquanto o RabbitMQ estiver fora),
/// declara a topologia e consome com prefetch 1 e ACK manual.
/// O ACK só é enviado depois que ProcessarAsync termina. Mensagem inválida é rejeitada
/// sem requeue; as demais falhas seguem TratarFalhaAsync.
/// </summary>
public abstract class ConsumidorRabbitMq : BackgroundService
{
    private readonly RabbitMqConnection _conexao;
    protected readonly ILogger Logger;

    protected ConsumidorRabbitMq(RabbitMqConnection conexao, ILogger logger)
    {
        _conexao = conexao;
        Logger = logger;
    }

    protected abstract string Fila { get; }

    protected abstract Task ProcessarAsync(BasicDeliverEventArgs ea, CancellationToken ct);

    /// <summary>Padrão: devolve a mensagem à fila uma vez; se falhar de novo, descarta.</summary>
    protected virtual async Task TratarFalhaAsync(IChannel channel, BasicDeliverEventArgs ea, Exception ex, CancellationToken ct)
    {
        var requeue = !ea.Redelivered;
        Logger.LogError(ex, "Falha ao processar {Evento} da {Fila}. Requeue: {Requeue}.", ea.RoutingKey, Fila, requeue);
        await channel.BasicNackAsync(ea.DeliveryTag, false, requeue, ct);
    }

    protected static T Ler<T>(BasicDeliverEventArgs ea) =>
        JsonMessageSerializer.Deserialize<T>(ea.Body)
        ?? throw new MensagemInvalidaException($"Corpo vazio em {ea.RoutingKey}.");

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        var connection = await ConectarAsync(stoppingToken);
        await using var channel = await connection.CreateChannelAsync(cancellationToken: stoppingToken);
        await RabbitMqTopologia.ConfigurarAsync(channel, stoppingToken);
        await channel.BasicQosAsync(0, 1, false, stoppingToken);

        var consumer = new AsyncEventingBasicConsumer(channel);
        consumer.ReceivedAsync += async (_, ea) =>
        {
            try
            {
                await ProcessarAsync(ea, stoppingToken);
                await channel.BasicAckAsync(ea.DeliveryTag, false, stoppingToken);
            }
            catch (Exception ex) when (ex is MensagemInvalidaException or JsonException)
            {
                Logger.LogError(ex, "Mensagem inválida em {Fila} ({Evento}); descartada.", Fila, ea.RoutingKey);
                await channel.BasicNackAsync(ea.DeliveryTag, false, false, stoppingToken);
            }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
            {
                // Encerrando: a mensagem sem ACK volta para a fila sozinha.
            }
            catch (Exception ex)
            {
                await TratarFalhaAsync(channel, ea, ex, stoppingToken);
            }
        };

        await channel.BasicConsumeAsync(Fila, false, consumer, stoppingToken);
        Logger.LogInformation("Consumindo {Fila} (PID {Pid}).", Fila, Environment.ProcessId);

        try
        {
            await Task.Delay(Timeout.Infinite, stoppingToken);
        }
        catch (OperationCanceledException)
        {
        }
    }

    private async Task<IConnection> ConectarAsync(CancellationToken ct)
    {
        while (true)
        {
            try
            {
                return await _conexao.GetConnectionAsync(ct);
            }
            catch (BrokerUnreachableException ex)
            {
                Logger.LogWarning("RabbitMQ indisponível ({Erro}). Nova tentativa em 5s...", ex.InnerException?.Message ?? ex.Message);
                await Task.Delay(TimeSpan.FromSeconds(5), ct);
            }
        }
    }
}

public sealed class MensagemInvalidaException : Exception
{
    public MensagemInvalidaException(string message) : base(message) { }
}
