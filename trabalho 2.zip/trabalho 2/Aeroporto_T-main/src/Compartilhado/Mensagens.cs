namespace Compartilhado;

// Contratos das mensagens trafegadas pelo RabbitMQ (serializadas em JSON).
// A routing key de cada mensagem é o nome do evento definido em RabbitMqNomes.

public sealed record SolicitarCheckIn(
    string CorrelationId,
    string PassageiroId,
    string NomePassageiro,
    string Voo,
    int QuantidadeBagagens,
    bool SimularErro,
    DateTime DataHora);

public sealed record CheckInRealizado(
    string CorrelationId,
    string PassageiroId,
    string NomePassageiro,
    string Voo,
    int QuantidadeBagagens,
    DateTime DataHora);

public sealed record VooAtrasado(
    string CorrelationId,
    string Voo,
    int AtrasoMinutos,
    string Motivo,
    DateTime NovoHorario);

public sealed record PortaoAlterado(
    string CorrelationId,
    string Voo,
    string PortaoAnterior,
    string NovoPortao);

public sealed record EmbarqueIniciado(
    string CorrelationId,
    string Voo,
    string? Portao,
    IReadOnlyList<string> PassageiroIds,
    DateTime DataHora);

public sealed record BagagemRegistrada(
    string CorrelationId,
    string PassageiroId,
    string NomePassageiro,
    string Voo,
    string CodigoBagagem,
    DateTime DataHora);
