namespace Compartilhado;

public sealed class RabbitMqSettings
{
    public string Host { get; set; } = "localhost";
    public int Port { get; set; } = 5672;
    public string User { get; set; } = "aeroporto";
    public string Password { get; set; } = "aeroporto123";
    public string VirtualHost { get; set; } = "/";
}
