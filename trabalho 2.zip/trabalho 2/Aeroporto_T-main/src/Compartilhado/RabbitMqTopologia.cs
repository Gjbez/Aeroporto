using RabbitMQ.Client;

namespace Compartilhado;

/// <summary>
/// Declara exchanges, filas e bindings. As declarações são idempotentes,
/// então qualquer serviço (produtor ou consumidor) pode chamar ao iniciar.
/// </summary>
public static class RabbitMqTopologia
{
    public static async Task ConfigurarAsync(IChannel channel, CancellationToken ct = default)
    {
        await channel.ExchangeDeclareAsync(RabbitMqNomes.ExchangeEventos, ExchangeType.Topic, durable: true, autoDelete: false, cancellationToken: ct);
        await channel.ExchangeDeclareAsync(RabbitMqNomes.ExchangeRetry, ExchangeType.Direct, durable: true, autoDelete: false, cancellationToken: ct);
        await channel.ExchangeDeclareAsync(RabbitMqNomes.ExchangeDlx, ExchangeType.Direct, durable: true, autoDelete: false, cancellationToken: ct);

        // fila.checkin: mensagem rejeitada (BasicNack requeue=false) vai para a DLX -> dlq.checkin.
        await channel.QueueDeclareAsync(
            RabbitMqNomes.FilaCheckIn,
            durable: true,
            exclusive: false,
            autoDelete: false,
            arguments: new Dictionary<string, object?>
            {
                ["x-dead-letter-exchange"] = RabbitMqNomes.ExchangeDlx,
                ["x-dead-letter-routing-key"] = RabbitMqNomes.SolicitarCheckIn
            },
            cancellationToken: ct);
        await channel.QueueBindAsync(RabbitMqNomes.FilaCheckIn, RabbitMqNomes.ExchangeEventos, RabbitMqNomes.SolicitarCheckIn, cancellationToken: ct);

        // fila.retry.checkin: não tem consumidor. Quando o TTL expira, a mensagem volta para fila.checkin.
        await channel.QueueDeclareAsync(
            RabbitMqNomes.FilaRetryCheckIn,
            durable: true,
            exclusive: false,
            autoDelete: false,
            arguments: new Dictionary<string, object?>
            {
                ["x-message-ttl"] = RabbitMqNomes.RetryTtlMs,
                ["x-dead-letter-exchange"] = RabbitMqNomes.ExchangeEventos,
                ["x-dead-letter-routing-key"] = RabbitMqNomes.SolicitarCheckIn
            },
            cancellationToken: ct);
        await channel.QueueBindAsync(RabbitMqNomes.FilaRetryCheckIn, RabbitMqNomes.ExchangeRetry, RabbitMqNomes.SolicitarCheckIn, cancellationToken: ct);

        await channel.QueueDeclareAsync(RabbitMqNomes.DlqCheckIn, durable: true, exclusive: false, autoDelete: false, cancellationToken: ct);
        await channel.QueueBindAsync(RabbitMqNomes.DlqCheckIn, RabbitMqNomes.ExchangeDlx, RabbitMqNomes.SolicitarCheckIn, cancellationToken: ct);

        await DeclararFilaAsync(channel, RabbitMqNomes.FilaBagagens, ct,
            RabbitMqNomes.CheckInRealizado,
            RabbitMqNomes.BagagemRegistrada);

        await DeclararFilaAsync(channel, RabbitMqNomes.FilaEmbarque, ct,
            RabbitMqNomes.CheckInRealizado,
            RabbitMqNomes.EmbarqueIniciado);

        await DeclararFilaAsync(channel, RabbitMqNomes.FilaNotificacoes, ct,
            RabbitMqNomes.CheckInRealizado,
            RabbitMqNomes.VooAtrasado,
            RabbitMqNomes.PortaoAlterado,
            RabbitMqNomes.EmbarqueIniciado,
            RabbitMqNomes.BagagemRegistrada);
    }

    private static async Task DeclararFilaAsync(IChannel channel, string fila, CancellationToken ct, params string[] routingKeys)
    {
        await channel.QueueDeclareAsync(fila, durable: true, exclusive: false, autoDelete: false, cancellationToken: ct);
        foreach (var key in routingKeys)
            await channel.QueueBindAsync(fila, RabbitMqNomes.ExchangeEventos, key, cancellationToken: ct);
    }
}
