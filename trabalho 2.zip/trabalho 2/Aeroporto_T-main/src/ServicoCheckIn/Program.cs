using Compartilhado;
using ServicoCheckIn;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddRabbitMq(builder.Configuration, "ServicoCheckIn");
builder.Services.AddSingleton<RegistroCheckIns>();
builder.Services.AddHostedService<ConsumidorCheckIn>();

var app = builder.Build();

app.MapGet("/", () => Results.Ok(new { servico = "Serviço de Check-in", status = "online" }));
app.MapGet("/health", () => Results.Ok(new { status = "ok" }));

// Recebe o pedido do passageiro e publica SOLICITAR_CHECKIN; o processamento é assíncrono.
app.MapPost("/checkins", async (SolicitarCheckInRequest request, RabbitMqPublicador publicador, RegistroCheckIns registro, CancellationToken ct) =>
{
    if (string.IsNullOrWhiteSpace(request.PassageiroId) || string.IsNullOrWhiteSpace(request.NomePassageiro) || string.IsNullOrWhiteSpace(request.Voo))
        return Results.BadRequest(new { erro = "passageiroId, nomePassageiro e voo são obrigatórios." });

    var mensagem = new SolicitarCheckIn(
        Guid.NewGuid().ToString(),
        request.PassageiroId,
        request.NomePassageiro,
        request.Voo.ToUpperInvariant(),
        Math.Max(0, request.QuantidadeBagagens ?? 1),
        request.SimularErro,
        DateTime.Now);

    registro.Salvar(new StatusCheckIn(mensagem.CorrelationId, mensagem.PassageiroId, mensagem.NomePassageiro,
        mensagem.Voo, mensagem.QuantidadeBagagens, RegistroCheckIns.Pendente, 0, null, DateTime.Now));

    await publicador.PublicarAsync(RabbitMqNomes.SolicitarCheckIn, mensagem, ct: ct);

    return Results.Accepted($"/checkins/{mensagem.CorrelationId}", new
    {
        mensagem = RabbitMqNomes.SolicitarCheckIn,
        correlationId = mensagem.CorrelationId,
        status = RegistroCheckIns.Pendente
    });
});

app.MapGet("/checkins", (RegistroCheckIns registro) => Results.Ok(registro.Todos));

app.MapGet("/checkins/{correlationId}", (string correlationId, RegistroCheckIns registro) =>
    registro.Obter(correlationId) is { } item ? Results.Ok(item) : Results.NotFound());

app.Run();

public record SolicitarCheckInRequest(
    string PassageiroId,
    string NomePassageiro,
    string Voo,
    int? QuantidadeBagagens,
    bool SimularErro = false);
