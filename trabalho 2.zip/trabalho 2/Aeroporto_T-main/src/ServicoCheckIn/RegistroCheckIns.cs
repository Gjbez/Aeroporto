using System.Collections.Concurrent;

namespace ServicoCheckIn;

public sealed record StatusCheckIn(
    string CorrelationId,
    string PassageiroId,
    string NomePassageiro,
    string Voo,
    int QuantidadeBagagens,
    string Status,
    int Tentativas,
    string? Erro,
    DateTime AtualizadoEm);

/// <summary>Registro em memória das operações de check-in (consulta via GET /checkins).</summary>
public sealed class RegistroCheckIns
{
    public const string Pendente = "PENDENTE";
    public const string EmRetry = "EM_RETRY";
    public const string Realizado = "REALIZADO";
    public const string Falhou = "FALHOU_DLQ";

    private readonly ConcurrentDictionary<string, StatusCheckIn> _itens = new();

    public IEnumerable<StatusCheckIn> Todos => _itens.Values.OrderBy(c => c.AtualizadoEm);

    public StatusCheckIn? Obter(string correlationId) =>
        _itens.TryGetValue(correlationId, out var item) ? item : null;

    public void Salvar(StatusCheckIn item) => _itens[item.CorrelationId] = item;

    public void Atualizar(string correlationId, string status, int tentativas, string? erro = null)
    {
        if (_itens.TryGetValue(correlationId, out var atual))
            _itens[correlationId] = atual with { Status = status, Tentativas = tentativas, Erro = erro, AtualizadoEm = DateTime.Now };
    }
}
