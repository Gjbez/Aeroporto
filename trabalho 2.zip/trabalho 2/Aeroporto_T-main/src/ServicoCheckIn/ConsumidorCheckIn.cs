using System.Text;
using Compartilhado;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;

namespace ServicoCheckIn;

/// <summary>
/// Consome SOLICITAR_CHECKIN da fila.checkin.
/// Sucesso: publica CHECKIN_REALIZADO e confirma (ACK).
/// Falha: republica na fila.retry.checkin (TTL) até o limite de tentativas;
/// depois rejeita (NACK sem requeue) e a DLX encaminha para a dlq.checkin.
/// </summary>
public sealed class ConsumidorCheckIn : ConsumidorRabbitMq
{
    private readonly RabbitMqPublicador _publicador;
    private readonly RegistroCheckIns _registro;

    public ConsumidorCheckIn(RabbitMqConnection conexao, RabbitMqPublicador publicador, RegistroCheckIns registro, ILogger<ConsumidorCheckIn> logger)
        : base(conexao, logger)
    {
        _publicador = publicador;
        _registro = registro;
    }

    protected override string Fila => RabbitMqNomes.FilaCheckIn;

    protected override async Task ProcessarAsync(BasicDeliverEventArgs ea, CancellationToken ct)
    {
        var solicitacao = Ler<SolicitarCheckIn>(ea);
        var tentativa = LerTentativa(ea);

        Logger.LogInformation("Processando SOLICITAR_CHECKIN {CorrelationId} (passageiro {PassageiroId}, voo {Voo}), tentativa {Tentativa}/{Max}.",
            solicitacao.CorrelationId, solicitacao.PassageiroId, solicitacao.Voo, tentativa, RabbitMqNomes.MaxTentativasCheckIn);

        if (solicitacao.SimularErro)
            throw new InvalidOperationException("Falha simulada no processamento do Check-in.");

        var realizado = new CheckInRealizado(
            solicitacao.CorrelationId,
            solicitacao.PassageiroId,
            solicitacao.NomePassageiro,
            solicitacao.Voo,
            solicitacao.QuantidadeBagagens,
            DateTime.Now);

        await _publicador.PublicarAsync(RabbitMqNomes.CheckInRealizado, realizado, ct: ct);
        _registro.Atualizar(solicitacao.CorrelationId, RegistroCheckIns.Realizado, tentativa);

        Logger.LogInformation("CHECKIN_REALIZADO publicado para {PassageiroId} no voo {Voo}.", solicitacao.PassageiroId, solicitacao.Voo);
    }

    protected override async Task TratarFalhaAsync(IChannel channel, BasicDeliverEventArgs ea, Exception ex, CancellationToken ct)
    {
        var solicitacao = Ler<SolicitarCheckIn>(ea);
        var tentativa = LerTentativa(ea);

        if (tentativa < RabbitMqNomes.MaxTentativasCheckIn)
        {
            var headers = new Dictionary<string, object?> { [RabbitMqNomes.HeaderTentativa] = tentativa + 1 };
            await _publicador.PublicarAsync(RabbitMqNomes.SolicitarCheckIn, solicitacao, headers, RabbitMqNomes.ExchangeRetry, ct);
            await channel.BasicAckAsync(ea.DeliveryTag, false, ct);

            _registro.Atualizar(solicitacao.CorrelationId, RegistroCheckIns.EmRetry, tentativa, ex.Message);
            Logger.LogWarning("Falha no check-in {CorrelationId} ({Erro}). Enviado para {Fila}; nova tentativa em {Ttl}s.",
                solicitacao.CorrelationId, ex.Message, RabbitMqNomes.FilaRetryCheckIn, RabbitMqNomes.RetryTtlMs / 1000);
        }
        else
        {
            // NACK sem requeue: o próprio RabbitMQ aplica o dead-letter (aeroporto.dlx -> dlq.checkin).
            await channel.BasicNackAsync(ea.DeliveryTag, false, false, ct);

            _registro.Atualizar(solicitacao.CorrelationId, RegistroCheckIns.Falhou, tentativa, ex.Message);
            Logger.LogError("Check-in {CorrelationId} falhou {Tentativa} vezes. Mensagem enviada via DLX para {Dlq}.",
                solicitacao.CorrelationId, tentativa, RabbitMqNomes.DlqCheckIn);
        }
    }

    private static int LerTentativa(BasicDeliverEventArgs ea)
    {
        var headers = ea.BasicProperties.Headers;
        if (headers is null || !headers.TryGetValue(RabbitMqNomes.HeaderTentativa, out var valor))
            return 1;

        return valor switch
        {
            byte b => b,
            sbyte sb => sb,
            short s => s,
            int i => i,
            long l => (int)l,
            byte[] bytes when int.TryParse(Encoding.UTF8.GetString(bytes), out var n) => n,
            _ => 1
        };
    }
}
