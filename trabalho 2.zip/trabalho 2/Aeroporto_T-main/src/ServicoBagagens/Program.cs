using Compartilhado;
using ServicoBagagens;

await Host.CreateDefaultBuilder(args)
    .ConfigureServices((context, services) =>
    {
        services.AddRabbitMq(context.Configuration, $"ServicoBagagens-{Environment.ProcessId}");
        services.AddHostedService<ConsumidorBagagens>();
    })
    .Build()
    .RunAsync();
