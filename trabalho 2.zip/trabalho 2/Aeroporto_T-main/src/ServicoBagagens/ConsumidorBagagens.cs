using Compartilhado;
using RabbitMQ.Client.Events;

namespace ServicoBagagens;

/// <summary>
/// Consome a fila.bagagens:
/// CHECKIN_REALIZADO -> associa as bagagens ao passageiro e publica BAGAGEM_REGISTRADA para cada uma;
/// BAGAGEM_REGISTRADA -> encaminha a bagagem para a triagem.
/// Pode rodar em várias instâncias: o RabbitMQ distribui as mensagens entre elas.
/// </summary>
public sealed class ConsumidorBagagens : ConsumidorRabbitMq
{
    private readonly RabbitMqPublicador _publicador;
    private readonly TimeSpan _tempoProcessamento;

    public ConsumidorBagagens(RabbitMqConnection conexao, RabbitMqPublicador publicador, IConfiguration configuration, ILogger<ConsumidorBagagens> logger)
        : base(conexao, logger)
    {
        _publicador = publicador;
        _tempoProcessamento = TimeSpan.FromMilliseconds(configuration.GetValue("TempoProcessamentoMs", 0));
    }

    protected override string Fila => RabbitMqNomes.FilaBagagens;

    protected override async Task ProcessarAsync(BasicDeliverEventArgs ea, CancellationToken ct)
    {
        // Simula o tempo de trabalho, para visualizar a divisão de carga entre instâncias.
        if (_tempoProcessamento > TimeSpan.Zero)
            await Task.Delay(_tempoProcessamento, ct);

        switch (ea.RoutingKey)
        {
            case RabbitMqNomes.CheckInRealizado:
                var checkIn = Ler<CheckInRealizado>(ea);
                if (checkIn.QuantidadeBagagens == 0)
                {
                    Logger.LogInformation("[PID {Pid}] {Nome} ({PassageiroId}) fez check-in sem bagagem despachada.",
                        Environment.ProcessId, checkIn.NomePassageiro, checkIn.PassageiroId);
                    return;
                }

                for (var i = 1; i <= checkIn.QuantidadeBagagens; i++)
                {
                    var codigo = $"BAG-{checkIn.Voo}-{Guid.NewGuid().ToString("N")[..6].ToUpperInvariant()}";
                    var bagagem = new BagagemRegistrada(checkIn.CorrelationId, checkIn.PassageiroId, checkIn.NomePassageiro, checkIn.Voo, codigo, DateTime.Now);
                    await _publicador.PublicarAsync(RabbitMqNomes.BagagemRegistrada, bagagem, ct: ct);

                    Logger.LogInformation("[PID {Pid}] Bagagem {Codigo} ({Indice}/{Total}) associada a {PassageiroId}, voo {Voo}. BAGAGEM_REGISTRADA publicada.",
                        Environment.ProcessId, codigo, i, checkIn.QuantidadeBagagens, checkIn.PassageiroId, checkIn.Voo);
                }
                break;

            case RabbitMqNomes.BagagemRegistrada:
                var registrada = Ler<BagagemRegistrada>(ea);
                Logger.LogInformation("[PID {Pid}] Bagagem {Codigo} encaminhada para triagem do voo {Voo}.",
                    Environment.ProcessId, registrada.CodigoBagagem, registrada.Voo);
                break;

            default:
                Logger.LogWarning("Evento inesperado na {Fila}: {Evento}.", Fila, ea.RoutingKey);
                break;
        }
    }
}
