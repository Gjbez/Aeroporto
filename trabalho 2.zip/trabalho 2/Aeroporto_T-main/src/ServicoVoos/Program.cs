using System.Collections.Concurrent;
using Compartilhado;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddRabbitMq(builder.Configuration, "ServicoVoos");

var app = builder.Build();

// Cadastro em memória com alguns voos de exemplo.
var voos = new ConcurrentDictionary<string, Voo>(StringComparer.OrdinalIgnoreCase);
var hoje = DateTime.Today;
foreach (var v in new[]
{
    new Voo("AB1234", "FLN", "GRU", hoje.AddHours(14).AddMinutes(30), "A1"),
    new Voo("AB5678", "FLN", "POA", hoje.AddHours(16), "A3"),
    new Voo("CD9012", "FLN", "BSB", hoje.AddHours(19).AddMinutes(15), "B2")
})
    voos[v.Numero] = v;

app.MapGet("/", () => Results.Ok(new { servico = "Serviço de Voos", status = "online" }));
app.MapGet("/health", () => Results.Ok(new { status = "ok" }));

app.MapGet("/voos", () => Results.Ok(voos.Values.OrderBy(v => v.Horario)));

app.MapGet("/voos/{numero}", (string numero) =>
    voos.TryGetValue(numero, out var voo) ? Results.Ok(voo) : Results.NotFound());

app.MapPost("/voos", (NovoVooRequest request) =>
{
    if (string.IsNullOrWhiteSpace(request.Numero))
        return Results.BadRequest(new { erro = "numero é obrigatório." });

    var voo = new Voo(request.Numero.ToUpperInvariant(), request.Origem, request.Destino, request.Horario, request.Portao);
    if (!voos.TryAdd(voo.Numero, voo))
        return Results.Conflict(new { erro = $"Voo {voo.Numero} já cadastrado." });

    return Results.Created($"/voos/{voo.Numero}", voo);
});

// Atualiza o voo e publica VOO_ATRASADO.
app.MapPost("/voos/{numero}/atraso", async (string numero, AtrasoRequest request, RabbitMqPublicador publicador, CancellationToken ct) =>
{
    if (!voos.TryGetValue(numero, out var voo))
        return Results.NotFound(new { erro = $"Voo {numero} não encontrado." });
    if (request.AtrasoMinutos <= 0)
        return Results.BadRequest(new { erro = "atrasoMinutos deve ser maior que zero." });

    voo.Horario = voo.Horario.AddMinutes(request.AtrasoMinutos);
    voo.Status = "ATRASADO";

    var mensagem = new VooAtrasado(Guid.NewGuid().ToString(), voo.Numero, request.AtrasoMinutos, request.Motivo, voo.Horario);
    await publicador.PublicarAsync(RabbitMqNomes.VooAtrasado, mensagem, ct: ct);

    return Results.Accepted($"/voos/{voo.Numero}", new { mensagem = RabbitMqNomes.VooAtrasado, voo });
});

// Atualiza o portão e publica PORTAO_ALTERADO.
app.MapPost("/voos/{numero}/portao", async (string numero, PortaoRequest request, RabbitMqPublicador publicador, CancellationToken ct) =>
{
    if (!voos.TryGetValue(numero, out var voo))
        return Results.NotFound(new { erro = $"Voo {numero} não encontrado." });
    if (string.IsNullOrWhiteSpace(request.NovoPortao))
        return Results.BadRequest(new { erro = "novoPortao é obrigatório." });

    var anterior = voo.Portao;
    voo.Portao = request.NovoPortao.ToUpperInvariant();

    var mensagem = new PortaoAlterado(Guid.NewGuid().ToString(), voo.Numero, anterior, voo.Portao);
    await publicador.PublicarAsync(RabbitMqNomes.PortaoAlterado, mensagem, ct: ct);

    return Results.Accepted($"/voos/{voo.Numero}", new { mensagem = RabbitMqNomes.PortaoAlterado, voo });
});

app.Run();

class Voo
{
    public Voo(string numero, string origem, string destino, DateTime horario, string portao)
    {
        Numero = numero;
        Origem = origem;
        Destino = destino;
        Horario = horario;
        Portao = portao;
    }

    public string Numero { get; }
    public string Origem { get; }
    public string Destino { get; }
    public DateTime Horario { get; set; }
    public string Portao { get; set; }
    public string Status { get; set; } = "PROGRAMADO";
}

record NovoVooRequest(string Numero, string Origem, string Destino, DateTime Horario, string Portao);
record AtrasoRequest(int AtrasoMinutos, string Motivo);
record PortaoRequest(string NovoPortao);
