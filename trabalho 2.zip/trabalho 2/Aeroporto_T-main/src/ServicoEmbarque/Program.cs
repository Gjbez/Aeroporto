using Compartilhado;
using ServicoEmbarque;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddRabbitMq(builder.Configuration, "ServicoEmbarque");
builder.Services.AddSingleton<ControleEmbarque>();
builder.Services.AddHostedService<ConsumidorEmbarque>();

var app = builder.Build();

app.MapGet("/", () => Results.Ok(new { servico = "Serviço de Embarque", status = "online" }));
app.MapGet("/health", () => Results.Ok(new { status = "ok" }));

// Passageiros do voo e situação de cada um.
app.MapGet("/embarques/{voo}", (string voo, ControleEmbarque controle) =>
    Results.Ok(new { voo = voo.ToUpperInvariant(), passageiros = controle.Passageiros(voo) }));

// Inicia o embarque do voo e publica EMBARQUE_INICIADO.
app.MapPost("/embarques/{voo}/iniciar", async (string voo, IniciarEmbarqueRequest? request, ControleEmbarque controle, RabbitMqPublicador publicador, CancellationToken ct) =>
{
    var passageiros = controle.Passageiros(voo)
        .Where(p => p.Status == ControleEmbarque.AguardandoEmbarque)
        .Select(p => p.PassageiroId)
        .ToList();

    var mensagem = new EmbarqueIniciado(Guid.NewGuid().ToString(), voo.ToUpperInvariant(), request?.Portao, passageiros, DateTime.Now);
    await publicador.PublicarAsync(RabbitMqNomes.EmbarqueIniciado, mensagem, ct: ct);

    return Results.Accepted($"/embarques/{mensagem.Voo}", new { mensagem = RabbitMqNomes.EmbarqueIniciado, mensagem.Voo, passageiros });
});

// Confirma que o passageiro passou pelo portão.
app.MapPost("/embarques/{voo}/passageiros/{passageiroId}/embarcar", (string voo, string passageiroId, ControleEmbarque controle) =>
{
    if (!controle.Existe(voo, passageiroId))
        return Results.NotFound(new { erro = "Passageiro sem check-in neste voo." });

    controle.AlterarStatus(voo, passageiroId, ControleEmbarque.Embarcado);
    return Results.Ok(new { voo = voo.ToUpperInvariant(), passageiroId, status = ControleEmbarque.Embarcado });
});

app.Run();

record IniciarEmbarqueRequest(string? Portao);
