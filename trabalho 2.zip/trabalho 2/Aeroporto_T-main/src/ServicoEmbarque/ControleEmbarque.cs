using System.Collections.Concurrent;

namespace ServicoEmbarque;

public sealed record PassageiroEmbarque(string PassageiroId, string Nome, string Status, DateTime AtualizadoEm);

/// <summary>Situação dos passageiros por voo, mantida em memória.</summary>
public sealed class ControleEmbarque
{
    public const string AguardandoEmbarque = "AGUARDANDO_EMBARQUE";
    public const string EmbarqueLiberado = "EMBARQUE_LIBERADO";
    public const string Embarcado = "EMBARCADO";

    private readonly ConcurrentDictionary<string, ConcurrentDictionary<string, PassageiroEmbarque>> _voos =
        new(StringComparer.OrdinalIgnoreCase);

    public IReadOnlyCollection<PassageiroEmbarque> Passageiros(string voo) =>
        _voos.TryGetValue(voo, out var lista) ? lista.Values.OrderBy(p => p.Nome).ToList() : Array.Empty<PassageiroEmbarque>();

    public void RegistrarCheckIn(string voo, string passageiroId, string nome) =>
        _voos.GetOrAdd(voo, _ => new())[passageiroId] = new PassageiroEmbarque(passageiroId, nome, AguardandoEmbarque, DateTime.Now);

    public void AlterarStatus(string voo, string passageiroId, string status)
    {
        if (_voos.TryGetValue(voo, out var lista) && lista.TryGetValue(passageiroId, out var p))
            lista[passageiroId] = p with { Status = status, AtualizadoEm = DateTime.Now };
    }

    public bool Existe(string voo, string passageiroId) =>
        _voos.TryGetValue(voo, out var lista) && lista.ContainsKey(passageiroId);
}
