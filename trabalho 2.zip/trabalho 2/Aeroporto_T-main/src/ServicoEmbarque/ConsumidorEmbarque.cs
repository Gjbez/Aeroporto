using Compartilhado;
using RabbitMQ.Client.Events;

namespace ServicoEmbarque;

/// <summary>
/// Consome a fila.embarque:
/// CHECKIN_REALIZADO -> passageiro passa a AGUARDANDO_EMBARQUE no voo;
/// EMBARQUE_INICIADO -> passageiros do voo passam a EMBARQUE_LIBERADO.
/// </summary>
public sealed class ConsumidorEmbarque : ConsumidorRabbitMq
{
    private readonly ControleEmbarque _controle;

    public ConsumidorEmbarque(RabbitMqConnection conexao, ControleEmbarque controle, ILogger<ConsumidorEmbarque> logger)
        : base(conexao, logger)
    {
        _controle = controle;
    }

    protected override string Fila => RabbitMqNomes.FilaEmbarque;

    protected override Task ProcessarAsync(BasicDeliverEventArgs ea, CancellationToken ct)
    {
        switch (ea.RoutingKey)
        {
            case RabbitMqNomes.CheckInRealizado:
                var checkIn = Ler<CheckInRealizado>(ea);
                _controle.RegistrarCheckIn(checkIn.Voo, checkIn.PassageiroId, checkIn.NomePassageiro);
                Logger.LogInformation("Embarque: {Nome} ({PassageiroId}) aguardando embarque no voo {Voo}.",
                    checkIn.NomePassageiro, checkIn.PassageiroId, checkIn.Voo);
                break;

            case RabbitMqNomes.EmbarqueIniciado:
                var embarque = Ler<EmbarqueIniciado>(ea);
                foreach (var id in embarque.PassageiroIds)
                    _controle.AlterarStatus(embarque.Voo, id, ControleEmbarque.EmbarqueLiberado);
                Logger.LogInformation("Embarque do voo {Voo} iniciado: {Qtd} passageiro(s) liberado(s).",
                    embarque.Voo, embarque.PassageiroIds.Count);
                break;

            default:
                Logger.LogWarning("Evento inesperado na {Fila}: {Evento}.", Fila, ea.RoutingKey);
                break;
        }

        return Task.CompletedTask;
    }
}
