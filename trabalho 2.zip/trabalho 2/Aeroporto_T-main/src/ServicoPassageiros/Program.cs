using Compartilhado;

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

app.MapGet("/", () => Results.Ok(new
{
    servico = "Serviço de Passageiros",
    status = "online"
}));

app.MapGet("/health", () => Results.Ok(new { status = "ok" }));

var passageiros = new Dictionary<string, object>();

app.MapPost("/passageiros", (PassageiroRequest request) =>
{
    if (string.IsNullOrWhiteSpace(request.Id) || string.IsNullOrWhiteSpace(request.Nome))
        return Results.BadRequest(new { erro = "Id e nome são obrigatórios." });

    passageiros[request.Id] = new
    {
        request.Id,
        request.Nome,
        request.Documento
    };

    return Results.Created($"/passageiros/{request.Id}", passageiros[request.Id]);
});

app.MapGet("/passageiros", () => Results.Ok(passageiros.Values));

app.MapGet("/passageiros/{id}", (string id) =>
    passageiros.TryGetValue(id, out var passageiro)
        ? Results.Ok(passageiro)
        : Results.NotFound());

app.Run();

record PassageiroRequest(string Id, string Nome, string Documento);
