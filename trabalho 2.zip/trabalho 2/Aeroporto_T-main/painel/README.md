# Painel de Simulação

Página web para acompanhar ao vivo as mensagens que passam pelo RabbitMQ e disparar os cenários do trabalho.
É um projeto separado: não altera nenhum serviço e não está na solução `AeroportoRabbitMQ.sln`.

## Como usar
1. Suba o RabbitMQ e os serviços (veja o README principal), de preferência com `.\scripts\subir-servicos.ps1 -Bagagens 2`.
2. Em outro terminal, na raiz do repositório:
   ```powershell
   dotnet run --project painel
   ```
3. Abra http://localhost:5100

## O que a página mostra
- **Status** de cada serviço e do RabbitMQ (as APIs via `/health`; os workers pela quantidade de consumidores na fila).
- **Diagrama do fluxo**: produtores → exchanges → filas → consumidores. Cada mensagem aparece como uma bolinha colorida percorrendo o caminho. As filas mostram quantas mensagens estão esperando e quantos consumidores têm.
- **Eventos ao vivo**, com exchange, routing key e tentativa (Retry/DLQ).
- **Tabelas** de check-ins, embarque do voo selecionado (com botão "Embarcar") e voos.

## Cenários prontos
- **Fluxo completo:** dois check-ins, atraso, troca de portão, início do embarque e embarque de um passageiro.
- **Check-in com falha:** 3 tentativas com 5 s de intervalo (fila.retry.checkin) e depois dlq.checkin.
- **Carga:** 8 check-ins com 2 bagagens cada. A `fila.bagagens` enche e é esvaziada pelas instâncias de Bagagens.

## Como funciona
- `Monitor.cs` cria uma fila **exclusiva e temporária** ligada às exchanges `aeroporto.events` (`#`), `aeroporto.retry` e `aeroporto.dlx`. Ela recebe uma cópia de cada mensagem sem tirar nada das filas dos serviços. Os eventos vão para a página por Server-Sent Events (`/api/eventos`).
- `/api/status` consulta as filas por declaração passiva (AMQP) e o `/health` das APIs.
- `/proxy/{servico}/...` repassa as ações da página para as APIs (portas 5101 a 5104), evitando CORS.
