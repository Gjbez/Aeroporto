using System.Text;
using System.Text.Json;
using System.Threading.Channels;
using Compartilhado;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;

namespace PainelSimulacao;

public sealed record EventoMonitor(
    long Id,
    DateTime Hora,
    string Exchange,
    string RoutingKey,
    int? Tentativa,
    bool RetornoRetry,
    JsonElement? Corpo);

/// <summary>Distribui os eventos capturados para as páginas abertas (Server-Sent Events).</summary>
public sealed class CentralEventos
{
    private const int MaxHistorico = 100;
    private readonly object _lock = new();
    private readonly LinkedList<EventoMonitor> _recentes = new();
    private readonly List<Channel<EventoMonitor>> _clientes = new();
    private long _seq;

    public long ProximoId() => Interlocked.Increment(ref _seq);

    public void Publicar(EventoMonitor evento)
    {
        lock (_lock)
        {
            _recentes.AddLast(evento);
            while (_recentes.Count > MaxHistorico)
                _recentes.RemoveFirst();

            foreach (var cliente in _clientes)
                cliente.Writer.TryWrite(evento);
        }
    }

    public (Channel<EventoMonitor> Canal, EventoMonitor[] Historico) Assinar()
    {
        var canal = Channel.CreateUnbounded<EventoMonitor>();
        lock (_lock)
        {
            _clientes.Add(canal);
            return (canal, _recentes.ToArray());
        }
    }

    public void Cancelar(Channel<EventoMonitor> canal)
    {
        lock (_lock)
            _clientes.Remove(canal);
        canal.Writer.TryComplete();
    }
}

/// <summary>
/// Observa o tráfego do RabbitMQ sem interferir nos serviços: cria uma fila exclusiva e temporária
/// ligada às três exchanges e recebe uma cópia de cada mensagem publicada.
/// </summary>
public sealed class MonitorRabbitMq : BackgroundService
{
    private readonly RabbitMqConnection _conexao;
    private readonly CentralEventos _central;
    private readonly ILogger<MonitorRabbitMq> _logger;

    public MonitorRabbitMq(RabbitMqConnection conexao, CentralEventos central, ILogger<MonitorRabbitMq> logger)
    {
        _conexao = conexao;
        _central = central;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await MonitorarAsync(stoppingToken);
                return;
            }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
            {
                return;
            }
            catch (Exception ex)
            {
                _logger.LogWarning("Monitor sem conexão com o RabbitMQ ({Erro}). Nova tentativa em 5s...", ex.Message);
                await Task.Delay(TimeSpan.FromSeconds(5), stoppingToken);
            }
        }
    }

    private async Task MonitorarAsync(CancellationToken ct)
    {
        var connection = await _conexao.GetConnectionAsync(ct);
        await using var channel = await connection.CreateChannelAsync(cancellationToken: ct);
        await RabbitMqTopologia.ConfigurarAsync(channel, ct);

        var fila = (await channel.QueueDeclareAsync("", durable: false, exclusive: true, autoDelete: true, cancellationToken: ct)).QueueName;
        await channel.QueueBindAsync(fila, RabbitMqNomes.ExchangeEventos, "#", cancellationToken: ct);
        await channel.QueueBindAsync(fila, RabbitMqNomes.ExchangeRetry, RabbitMqNomes.SolicitarCheckIn, cancellationToken: ct);
        await channel.QueueBindAsync(fila, RabbitMqNomes.ExchangeDlx, RabbitMqNomes.SolicitarCheckIn, cancellationToken: ct);

        var consumer = new AsyncEventingBasicConsumer(channel);
        consumer.ReceivedAsync += (_, ea) =>
        {
            _central.Publicar(Converter(ea));
            return Task.CompletedTask;
        };

        await channel.BasicConsumeAsync(fila, autoAck: true, consumer, ct);
        _logger.LogInformation("Monitor observando o RabbitMQ pela fila {Fila}.", fila);

        await Task.Delay(Timeout.Infinite, ct);
    }

    private EventoMonitor Converter(BasicDeliverEventArgs ea)
    {
        JsonElement? corpo = null;
        try
        {
            using var doc = JsonDocument.Parse(ea.Body);
            corpo = doc.RootElement.Clone();
        }
        catch (JsonException)
        {
        }

        var headers = ea.BasicProperties.Headers;
        int? tentativa = null;
        if (headers is not null && headers.TryGetValue(RabbitMqNomes.HeaderTentativa, out var valor))
        {
            tentativa = valor switch
            {
                byte b => b,
                short s => s,
                int i => i,
                long l => (int)l,
                byte[] bytes when int.TryParse(Encoding.UTF8.GetString(bytes), out var n) => n,
                _ => null
            };
        }

        // x-death é adicionado pelo RabbitMQ quando a mensagem passa por dead-lettering (ex.: TTL expirou).
        var retornoRetry = headers?.ContainsKey("x-death") == true;

        return new EventoMonitor(_central.ProximoId(), DateTime.Now, ea.Exchange, ea.RoutingKey, tentativa, retornoRetry, corpo);
    }
}

public sealed record InfoFila(string Nome, uint Mensagens, uint Consumidores);

/// <summary>Consulta mensagens e consumidores de cada fila (declaração passiva via AMQP).</summary>
public sealed class InspetorFilas
{
    private static readonly string[] Filas =
    {
        RabbitMqNomes.FilaCheckIn,
        RabbitMqNomes.FilaRetryCheckIn,
        RabbitMqNomes.DlqCheckIn,
        RabbitMqNomes.FilaBagagens,
        RabbitMqNomes.FilaEmbarque,
        RabbitMqNomes.FilaNotificacoes
    };

    private readonly RabbitMqConnection _conexao;
    private readonly SemaphoreSlim _lock = new(1, 1);
    private IChannel? _canal;
    private DateTime _ultimaFalha = DateTime.MinValue;

    public InspetorFilas(RabbitMqConnection conexao) => _conexao = conexao;

    public async Task<List<InfoFila>?> ContarAsync(CancellationToken ct)
    {
        // Evita empilhar tentativas de conexão enquanto o broker estiver fora.
        if (DateTime.Now - _ultimaFalha < TimeSpan.FromSeconds(3))
            return null;

        await _lock.WaitAsync(ct);
        try
        {
            if (_canal is not { IsOpen: true })
            {
                var conn = await _conexao.GetConnectionAsync(ct);
                _canal = await conn.CreateChannelAsync(cancellationToken: ct);
                await RabbitMqTopologia.ConfigurarAsync(_canal, ct);
            }

            var lista = new List<InfoFila>();
            foreach (var fila in Filas)
            {
                var ok = await _canal.QueueDeclarePassiveAsync(fila, ct);
                lista.Add(new InfoFila(fila, ok.MessageCount, ok.ConsumerCount));
            }
            return lista;
        }
        catch (Exception) when (!ct.IsCancellationRequested)
        {
            _canal = null;
            _ultimaFalha = DateTime.Now;
            return null;
        }
        finally
        {
            _lock.Release();
        }
    }
}
