using System.Text.Json;
using Compartilhado;
using PainelSimulacao;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddRabbitMq(builder.Configuration, "PainelSimulacao");
builder.Services.AddSingleton<CentralEventos>();
builder.Services.AddSingleton<InspetorFilas>();
builder.Services.AddHostedService<MonitorRabbitMq>();
builder.Services.AddHttpClient("servicos", c => c.Timeout = TimeSpan.FromSeconds(5));

var app = builder.Build();
app.UseDefaultFiles();
app.UseStaticFiles();

var servicos = builder.Configuration.GetSection("Servicos").Get<Dictionary<string, string>>() ?? new();
var json = new JsonSerializerOptions(JsonSerializerDefaults.Web);

// Fluxo de eventos ao vivo (Server-Sent Events): primeiro o histórico recente, depois cada mensagem nova.
app.MapGet("/api/eventos", async (HttpContext ctx, CentralEventos central) =>
{
    ctx.Response.Headers.CacheControl = "no-cache";
    ctx.Response.ContentType = "text/event-stream";

    var (canal, historico) = central.Assinar();
    try
    {
        await EnviarAsync("historico", historico);
        await foreach (var evento in canal.Reader.ReadAllAsync(ctx.RequestAborted))
            await EnviarAsync("evento", evento);
    }
    catch (OperationCanceledException)
    {
    }
    finally
    {
        central.Cancelar(canal);
    }

    async Task EnviarAsync(string tipo, object dados)
    {
        await ctx.Response.WriteAsync($"event: {tipo}\ndata: {JsonSerializer.Serialize(dados, json)}\n\n", ctx.RequestAborted);
        await ctx.Response.Body.FlushAsync(ctx.RequestAborted);
    }
});

// Situação dos serviços HTTP e das filas.
app.MapGet("/api/status", async (InspetorFilas inspetor, IHttpClientFactory factory, CancellationToken ct) =>
{
    var http = factory.CreateClient("servicos");
    var checks = servicos.Select(async kv =>
    {
        try
        {
            using var cts = CancellationTokenSource.CreateLinkedTokenSource(ct);
            cts.CancelAfter(TimeSpan.FromMilliseconds(800));
            using var resp = await http.GetAsync($"{kv.Value}/health", cts.Token);
            return (Nome: kv.Key, Online: resp.IsSuccessStatusCode);
        }
        catch (Exception)
        {
            return (Nome: kv.Key, Online: false);
        }
    });

    var resultados = await Task.WhenAll(checks);
    var filas = await inspetor.ContarAsync(ct);

    return Results.Ok(new
    {
        rabbitmq = filas is not null,
        servicos = resultados.ToDictionary(r => r.Nome, r => r.Online),
        filas = filas ?? new List<InfoFila>()
    });
});

// Repassa as chamadas da página para as APIs dos serviços (evita CORS).
app.Map("/proxy/{servico}/{**caminho}", async (HttpContext ctx, string servico, string? caminho, IHttpClientFactory factory) =>
{
    if (!servicos.TryGetValue(servico, out var baseUrl))
    {
        ctx.Response.StatusCode = StatusCodes.Status404NotFound;
        return;
    }

    using var req = new HttpRequestMessage(new HttpMethod(ctx.Request.Method), $"{baseUrl.TrimEnd('/')}/{caminho}{ctx.Request.QueryString}");
    if (ctx.Request.ContentLength > 0)
    {
        req.Content = new StreamContent(ctx.Request.Body);
        if (ctx.Request.ContentType is { } contentType)
            req.Content.Headers.TryAddWithoutValidation("Content-Type", contentType);
    }

    try
    {
        using var resp = await factory.CreateClient("servicos").SendAsync(req, ctx.RequestAborted);
        ctx.Response.StatusCode = (int)resp.StatusCode;
        ctx.Response.ContentType = resp.Content.Headers.ContentType?.ToString() ?? "application/json";
        await resp.Content.CopyToAsync(ctx.Response.Body);
    }
    catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException && !ctx.RequestAborted.IsCancellationRequested)
    {
        ctx.Response.StatusCode = StatusCodes.Status503ServiceUnavailable;
        await ctx.Response.WriteAsJsonAsync(new { erro = $"Serviço '{servico}' está offline." });
    }
});

app.Run();
