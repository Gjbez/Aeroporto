# Sistema Distribuído de Gerenciamento de Aeroporto com RabbitMQ

Implementação em C#/.NET do trabalho descrito em `Trabalho Aeroporto.docx`: seis serviços independentes que se comunicam de forma assíncrona pelo RabbitMQ.

## Integrantes
Frederico Rudolf Uesler, João Gabriel Vargas, Guilherme Ricardo Bez Junior, Jose Leonardo Perich, Samuel Ramiro da Costa Alfarth

## Requisitos
- .NET SDK 6 ou superior (o projeto é `net6.0` com `RollForward=Major`, então roda também com o .NET 8)
- RabbitMQ 3.x ou 4.x, via Docker ou instalado no Windows

## 1. Subir o RabbitMQ

**Docker (mais simples):**
```powershell
docker run -d --name rabbitmq -p 5672:5672 -p 15672:15672 rabbitmq:3-management
docker exec rabbitmq rabbitmqctl add_user aeroporto aeroporto123
docker exec rabbitmq rabbitmqctl set_permissions -p / aeroporto ".*" ".*" ".*"
docker exec rabbitmq rabbitmqctl set_user_tags aeroporto management
```

**Instalado no Windows:** execute `scripts/configurar-rabbitmq.ps1` como Administrador.

Painel: http://localhost:15672 (usuário `aeroporto`, senha `aeroporto123`).

As filas e exchanges são criadas automaticamente pelos serviços ao iniciar.

## 2. Subir os serviços

```powershell
.\scripts\subir-servicos.ps1              # uma janela por serviço
.\scripts\subir-servicos.ps1 -Bagagens 2  # duas instâncias de Bagagens (escalabilidade)
```

Ou manualmente, um terminal por serviço: `dotnet run --project src/ServicoCheckIn` etc.

| Serviço | Tipo | Porta | Papel |
|---|---|---|---|
| Passageiros | API | 5101 | cadastro e consulta de passageiros |
| Voos | API | 5102 | voos, horários, status e portões; produz `VOO_ATRASADO` e `PORTAO_ALTERADO` |
| Check-in | API + consumidor | 5103 | produz `SOLICITAR_CHECKIN`, consome `fila.checkin`, produz `CHECKIN_REALIZADO` |
| Embarque | API + consumidor | 5104 | consome `fila.embarque`, produz `EMBARQUE_INICIADO` |
| Bagagens | worker | — | consome `fila.bagagens`, produz `BAGAGEM_REGISTRADA` |
| Notificações | worker | — | consome `fila.notificacoes` e envia as mensagens aos passageiros (console) |

## 3. Testar

Use o arquivo `Testes.http` (extensão REST Client do VS Code) na ordem. Exemplo em PowerShell:

```powershell
$h = @{ "Content-Type" = "application/json" }
Invoke-RestMethod http://localhost:5103/checkins -Method POST -Headers $h -Body '{"passageiroId":"P001","nomePassageiro":"Frederico","voo":"AB1234","quantidadeBagagens":2}'
Invoke-RestMethod http://localhost:5102/voos/AB1234/atraso -Method POST -Headers $h -Body '{"atrasoMinutos":45,"motivo":"Chuva"}'
Invoke-RestMethod http://localhost:5102/voos/AB1234/portao -Method POST -Headers $h -Body '{"novoPortao":"B12"}'
Invoke-RestMethod http://localhost:5104/embarques/AB1234/iniciar -Method POST -Headers $h -Body '{"portao":"B12"}'
```

O que observar:
- **Fluxo de check-in:** `SOLICITAR_CHECKIN` → Check-in → `CHECKIN_REALIZADO` → Bagagens (registra e publica `BAGAGEM_REGISTRADA`), Embarque (passageiro fica `AGUARDANDO_EMBARQUE`) e Notificações (confirmação ao passageiro).
- **Falha no check-in** (`"simularErro": true`): a mensagem vai para `fila.retry.checkin`, espera o TTL de 5 s e volta para `fila.checkin`. Depois de 3 tentativas o consumidor faz NACK e a DLX `aeroporto.dlx` a encaminha para `dlq.checkin` (veja no painel). `GET /checkins` mostra `EM_RETRY` e depois `FALHOU_DLQ`.
- **Escalabilidade:** com `-Bagagens 2`, o log de cada instância mostra o PID; as mensagens da `fila.bagagens` são divididas entre elas.
- **Tolerância a falhas:** feche a janela de Notificações, altere um portão e veja a mensagem esperando em `fila.notificacoes` no painel. Ao reabrir o serviço, ela é entregue.

## Problemas comuns
- **`PRECONDITION_FAILED ... x-dead-letter-exchange` ao iniciar:** a `fila.checkin` foi criada por uma versão anterior sem DLX. Apague-a no painel (Queues → fila.checkin → Delete) e reinicie o Check-in.
- **`ACCESS_REFUSED`:** o usuário `aeroporto` não existe ou está sem permissão no vhost `/` (veja o passo 1).
